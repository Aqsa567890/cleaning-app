package com.example.uni_tech.ics1;

import android.content.Intent;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

public class Categories extends AppCompatActivity {
    private DrawerLayout nDrawerLayout;
    private ActionBarDrawerToggle nToggle;
       ImageButton clean,road,pest,mover;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView(R.layout.activity_categories );
        ImageButton clean =(ImageButton) findViewById( R.id.clean );
        ImageButton road =(ImageButton) findViewById( R.id.road );
        ImageButton pest =(ImageButton) findViewById( R.id.pest );
        ImageButton mover =(ImageButton) findViewById( R.id.mover );

        clean.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentA = new Intent(Categories.this,Cleaning.class);
                startActivity( intentA );
            }
        } );

        road.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentB = new Intent(Categories.this,PestController.class);
                startActivity( intentB );

            }
        } );

          pest.setOnClickListener( new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Intent intentC = new Intent (Categories.this,RoadAssistant.class);
                  startActivity( intentC );
              }
          } );
          mover.setOnClickListener( new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  Intent intentD = new Intent (Categories.this,MoverPacker.class);
                  startActivity( intentD );

              }
          } );

        nDrawerLayout = (DrawerLayout) findViewById(R.id.drawer );
        nToggle = new ActionBarDrawerToggle(this,nDrawerLayout,R.string.open,R.string.close );
        nDrawerLayout.addDrawerListener( nToggle );
        nToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled( true );
    }
     @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(nToggle.onOptionsItemSelected( item )){
            return true;
        }
        return super.onOptionsItemSelected( item );

     }
}