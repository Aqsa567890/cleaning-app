package com.example.uni_tech.ics1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Register extends AppCompatActivity {
    Button btnregister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView(R.layout.activity_register );

        Button btnregister = (Button) findViewById(R.id.btnregister );
         btnregister.setOnClickListener( new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 Intent intent3 = new Intent( Register.this,Categories.class );
                 startActivity( intent3 );
             }
         } );

    }
}

