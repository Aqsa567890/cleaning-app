package com.example.uni_tech.ics1;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;

public class front extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView(R.layout.activity_front );
        ImageView imageView = (ImageView) findViewById( R.id.imageView );
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(),R.drawable.logo1);
        RoundedBitmapDrawable roundedBitmapDrawable = RoundedBitmapDrawableFactory.create(getResources(),bitmap);
        roundedBitmapDrawable.setCircular(true);
        imageView.setImageDrawable(roundedBitmapDrawable);

        Thread myThread = new Thread(  ){
            @Override
            public void run() {
                try {
                    sleep(3000);
                    Intent intent1 = new Intent( getApplicationContext(),Login.class);
                    startActivity( intent1 );
                    finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        myThread.start();
    }
}
